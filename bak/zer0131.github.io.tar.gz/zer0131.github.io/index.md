---
layout: page
title: Welcome Everybody
---
## 五环小胖子的博客

![RuiBlog](http://7xj4mc.com1.z0.glb.clouddn.com/rui_blog.jpg)

## OneFox轻量级框架

小的不才，用业余时间写了一个轻量级的PHP框架，[OneFox](http://www.zhangenrui.cn)

## 关于Coding

都说人生有有三重境界，第一重境界：看山是山，看水是水；第二重境界：看山不是山，看水不是水；第三重境界：看山还是山，看水还是水。人生如此，搞技术也是如此，需要经历这三重境界才能出任CEO，赢取白富美，走上技术颠峰。

![RuiBlog_1](http://7xj4mc.com1.z0.glb.clouddn.com/index_img1.jpg)

## 手机访问本站

请用手机扫描二维码

![扫描二维码](http://7xj4mc.com1.z0.glb.clouddn.com/cli_250px.png)

## 特别感谢

本博客通过 [Jekyll](http://jekyllrb.com/) 生成，部署在 [Github](https://pages.github.com)，主题参考了 [3-Jekyll](https://github.com/P233/3-Jekyll) 和 [suyan](https://github.com/suyan/suyan.github.io)，非常感谢两位的提供。

RuiBlog源码托管在[Github](https://github.com/zer0131/zer0131.github.io)上，欢迎小伙伴们来喷。
