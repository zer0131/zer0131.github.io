---
layout: post
title: vim常用命令总结
category: linux
description: 自己总结和制作的vim基础命令图片，供大家参考。
---

## 小感想

这段时间一直在研究linux相关的东西，说实在的linux不管作为开发工具还是服务器，那都是相当的强悍的。

尤其是Linux下的vim编辑器是堪称经典，我花了点时间总结了一下vim中常用的基本命令，供大家学习和参考。

## 命令图片

![vim cmd 1](http://7xj4mc.com1.z0.glb.clouddn.com/vim_1.png)

![vim cmd 2](http://7xj4mc.com1.z0.glb.clouddn.com/vim_2.png)

![vim cmd 3](http://7xj4mc.com1.z0.glb.clouddn.com/vim_3.png)

![vim cmd 4](http://7xj4mc.com1.z0.glb.clouddn.com/vim_4.png)

![vim cmd 5](http://7xj4mc.com1.z0.glb.clouddn.com/vim_4.png)