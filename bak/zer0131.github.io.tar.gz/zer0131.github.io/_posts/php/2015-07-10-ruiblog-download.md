---
layout: post
title: RUIBlog迁移说明
category: php
keywords: ThinkPHP,PHP,RUIBlog
description: RUIBlog个人博客系统迁移及下载说明
---

由于服务器到期，之前的**RUIBLog个人博客系统**的相关东东迁移至本博客。这次迁移给使用RUIBlog的朋友带来的不便敬请谅解。

## 下载

> [RUIBlog_1.5](http://pan.baidu.com/s/1eQnQa)
> [RUIBlog_1.0](http://pan.baidu.com/share/link?shareid=548956950&uk=1846304022)

## 相关截图

![ruiblog_1](http://7xj4mc.com1.z0.glb.clouddn.com/ruiblog_1.jpg)

![ruiblog_2](http://7xj4mc.com1.z0.glb.clouddn.com/ruiblog_2.jpg)

![ruiblog_3](http://7xj4mc.com1.z0.glb.clouddn.com/ruiblog_3.png)

![ruiblog_4](http://7xj4mc.com1.z0.glb.clouddn.com/ruiblog_4.png)

## 交流群

**161047775**